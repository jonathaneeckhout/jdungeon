Bear growls.

Licensing:
  - Creative Commons Zero (CC0)

Source:
  - From the U.S. Fish & Wildlife Service: https://www.fws.gov/video/sound.htm
